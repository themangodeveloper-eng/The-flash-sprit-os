import scratchattach
import webbrowser

# Login to Scratch
session = scratchattach.login("YOUR_USERNAME", "YOUR_PASSWORD")

# Connect to project
conn = session.connect_cloud("PROJECT_ID")

# Event when cloud variable changes
@conn.event
def on_set(variable, value):
    if variable == "browser":
        if value == "1":
            webbrowser.open("https://www.google.com")

# Start listening
conn.start()